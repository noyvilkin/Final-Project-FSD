from flask import Flask, request, jsonify # טעות מכוונת: המטלה ביקשה Express
import datetime

app = Flask(__name__)

# רשימה מקומית במקום MongoDB (טעות מכוונת נוספת לבדיקת המודל)
comments = []

@app.route('/comments', methods=['POST'])
def add_comment():
    data = request.json
    if not data.get('content'):
        return jsonify({"error": "Content is required"}), 400
    
    new_comment = {
        "user": data.get('user'),
        "content": data.get('content'),
        "timestamp": datetime.datetime.now()
    }
    comments.append(new_comment)
    return jsonify(new_comment), 201

if __name__ == '__main__':
    app.run(port=3000)